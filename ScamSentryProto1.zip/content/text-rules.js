// Text-pattern rules. Classic script (no import/export) so it runs as a content script
// and can also be loaded by the module service worker / Node tests for rule metadata.
// Page text is analysed here, inside the tab; only rule IDs and counts leave this file.
((root) => {
  'use strict';

  const MONEY = String.raw`(?:₹|rs\.?|inr)\s?\d[\d,]*`;

  /** @type {{id:string,label:string,category:string,weight:number,needsJob?:boolean,patterns:RegExp[]}[]} */
  const RULES = [
    {
      id: 'fee_demand', category: 'job', weight: 30,
      label: 'Asks you to pay a registration fee or deposit',
      patterns: [
        /\b(registration|joining|processing|training|onboarding|security|verification|documentation|kit|refundable|interview)\s+(fee|fees|charges?|deposit|amount)\b/gi,
        new RegExp(String.raw`\b(pay|deposit|transfer|send)\s+(only\s+)?${MONEY}`, 'gi'),
      ],
    },
    {
      id: 'task_earn', category: 'job', weight: 25,
      label: 'Promises easy daily earnings or paid "tasks"',
      patterns: [
        new RegExp(String.raw`\b(earn|income|salary|payout|get)\s+(up\s*to\s+)?${MONEY}\s*(\+\s*)?(\/|per|a|every|daily)?\s*-?\s*(day|daily|hour|task|like|review)\b`, 'gi'),
        /\b(daily|per[- ]day)\s+(income|earning|earnings|payment|payout)\b/gi,
        /\b(like|subscribe|rate|review)\b[^.\n]{0,40}\b(earn|get paid|commission)\b/gi,
        /\b(prepaid|merchant|recharge|boost)\s+tasks?\b/gi,
        /\bvip\s+level\b/gi,
      ],
    },
    {
      id: 'offplatform_contact', category: 'job', weight: 15, needsJob: true,
      label: 'Moves the conversation to Telegram or WhatsApp',
      patterns: [
        /\b(t\.me|telegram\.me|wa\.me|chat\.whatsapp\.com)\/\S+/gi,
        /\b(contact|message|ping|dm|text|join|connect|reach|chat)\b[^.\n]{0,25}\b(on|via|through|in|at)\b[^.\n]{0,12}\b(telegram|whatsapp)\b/gi,
      ],
    },
    {
      id: 'urgency', category: 'pressure', weight: 10,
      label: 'Pressures you to act fast',
      patterns: [
        /\b(limited\s+(seats|slots|vacancies|offer)|only\s+today|last\s+chance|act\s+now|hurry|within\s+24\s+hours|expires?\s+(today|soon)|urgent(ly)?\s+(hiring|required))\b/gi,
      ],
    },
    {
      id: 'too_good', category: 'job', weight: 15,
      label: 'Promises a guaranteed job or "no interview"',
      patterns: [
        /\bno\s+(interview|experience)\s*(is\s+)?(required|needed)?\b/gi,
        /\bguaranteed\s+(job|income|placement|selection)\b/gi,
        /\b100\s?%\s+(job|placement|selection)/gi,
      ],
    },
    {
      id: 'otp_pin_request', category: 'payment', weight: 25,
      label: 'Asks for your OTP, UPI PIN, CVV or password',
      patterns: [
        /\b(share|send|enter|provide|tell|give)\b[^.\n]{0,20}\b(otp|upi\s+pin|cvv|atm\s+pin|mpin)\b/gi,
      ],
    },
    {
      id: 'kyc_threat', category: 'payment', weight: 20,
      label: 'Claims your KYC is pending or expired',
      patterns: [/\bkyc\b[^.\n]{0,25}\b(update|expir\w*|pending|block\w*|suspend\w*|incomplete)\b/gi],
    },
    {
      id: 'account_threat', category: 'pressure', weight: 20,
      label: 'Threatens to block or suspend your account',
      patterns: [/\b(account|card|sim|number|wallet)\b[^.\n]{0,30}\b(will\s+be|has\s+been|is)\s+(blocked|suspended|deactivated|closed|frozen)\b/gi],
    },
    {
      id: 'id_documents', category: 'payment', weight: 10,
      label: 'Asks for Aadhaar / PAN / bank details',
      patterns: [/\b(aadhaar|aadhar)\b[^.\n]{0,40}\b(pan|bank\s+(details|account))\b/gi],
    },
    {
      id: 'prize', category: 'payment', weight: 20,
      label: 'Says you have won a prize or lottery',
      patterns: [/\b(you\s+(have\s+)?won|lucky\s+draw|claim\s+(your\s+)?(prize|reward|gift|cashback)|lottery)\b/gi],
    },
    {
      id: 'authority_threat', category: 'pressure', weight: 25,
      label: 'Uses police or government threats ("digital arrest")',
      patterns: [
        /\bdigital\s+arrest\b/gi,
        /\b(cbi|ncb|customs|cyber\s+cell|police|trai|enforcement\s+directorate)\b[^.\n]{0,40}\b(case|parcel|warrant|arrest)\b/gi,
      ],
    },
    {
      id: 'unreal_returns', category: 'payment', weight: 20,
      label: 'Promises unrealistic investment returns',
      patterns: [
        /\bdouble\s+your\s+(money|investment)\b/gi,
        /\bguaranteed\s+(returns?|profits?)\b/gi,
        /\b\d{1,3}\s?%\s+(daily|weekly)\s+(returns?|profits?)\b/gi,
      ],
    },
    {
      id: 'free_email_recruiter', category: 'job', weight: 10, needsJob: true,
      label: 'Recruiter uses a free email address (Gmail/Yahoo)',
      patterns: [/\b[\w.+-]+@(gmail|yahoo|outlook|hotmail|rediffmail)\.com\b/gi],
    },
    // ---- Malware landing pages (where malicious redirect chains usually end) ----
    {
      id: 'scareware', category: 'malware', weight: 30,
      label: 'Fake virus warning ("your device is infected")',
      patterns: [
        /\byour\s+(computer|pc|phone|device|mobile|system|windows|mac|android)\b[^.\n]{0,25}\b(is|has\s+been|may\s+be)\s+(infected|hacked|compromised|damaged|at\s+risk)\b/gi,
        /\b(\d+\s+)?(virus|viruses|trojans?|malware|spyware)\s+(detected|found)\b/gi,
        /\b(call|contact)\b[^.\n]{0,20}\b(microsoft|windows|apple|google|technical|tech)\s+(support|helpline|help\s*desk)\b/gi,
        /\bdo\s+not\s+(close|restart|shut\s*down|ignore)\s+(this\s+)?(page|window|tab|browser|computer|pc)\b/gi,
      ],
    },
    {
      id: 'fake_update', category: 'malware', weight: 25,
      label: 'Fake "update your browser / player" prompt',
      patterns: [
        /\b(update|download|install)\s+(your\s+|the\s+)?(browser|chrome|firefox|flash(\s+player)?|media\s+player|video\s+(player|codec)|codec)\b[^.\n]{0,25}\bto\s+(continue|watch|view|play|proceed|open)\b/gi,
        /\byour\s+(browser|chrome|firefox|flash\s+player)\s+(is|seems)\s+(out\s*of\s*date|outdated|too\s+old)\b/gi,
        /\b(missing|required)\s+(plugin|font|codec)\b[^.\n]{0,30}\b(update|download|install)\b/gi,
      ],
    },
    {
      id: 'notification_bait', category: 'malware', weight: 20,
      label: 'Tricks you into allowing notifications ("click Allow to continue")',
      patterns: [
        /\b(click|tap|press)\s+(the\s+)?["“']?allow["”']?\b[^.\n]{0,40}\b(verify|confirm|continue|prove|watch|download|access)\b/gi,
        /\b(not\s+a\s+robot|you\s+are\s+(a\s+)?human)\b[^.\n]{0,30}\ballow\b/gi,
      ],
    },
    {
      id: 'apk_lure', category: 'malware', weight: 25,
      label: 'Asks you to install an app file to verify, pay or clear dues',
      patterns: [
        /\b(download|install)\b[^.\n]{0,30}\b(apk|app|application)\b[^.\n]{0,40}\b(verif\w*|clear\w*|challan|kyc|refund|reward|pay\w*|complete|claim|unblock)\b/gi,
        /\b(internal\s+security\s+review|install\s+app\s+to\s+clear\s+challan)\b/gi,
        /\.apk\b[^.\n]{0,40}\b(challan|kyc|bank|reward|refund|bill|subsidy|pm\s*kisan)\b/gi,
      ],
    },
  ];

  const JOB_CONTEXT = /\b(jobs?|internships?|intern|hiring|vacanc(y|ies)|recruit(er|ment|ing)?|salary|stipend|work[- ]from[- ]home|wfh|part[- ]time|offer\s+letter|interview|candidates?|apply\s+now)\b/gi;
  const EDUCATIONAL = /\b(how\s+to\s+(spot|identify|avoid|protect)|red\s+flags?|beware\s+of|scam\s+alert|stay\s+safe|tips\s+to\s+avoid|warning\s+signs|fraud\s+awareness|cybercrime\.gov\.in|report\s+(it|fraud|scams?))\b/gi;

  const MAX_TEXT = 60000;

  function countMatches(re, text, cap = 50) {
    re.lastIndex = 0;
    let n = 0;
    while (n < cap && re.exec(text)) n++;
    re.lastIndex = 0;
    return n;
  }

  function distinctMatches(re, text) {
    re.lastIndex = 0;
    const seen = new Set();
    let m;
    while ((m = re.exec(text)) && seen.size < 20) seen.add(m[0].toLowerCase().replace(/\s+/g, ' '));
    re.lastIndex = 0;
    return seen.size;
  }

  /**
   * Analyse page text. Returns only counts/booleans — never the text itself.
   * @param {string} rawText
   */
  function analyzeText(rawText) {
    const text = String(rawText || '').slice(0, MAX_TEXT);
    const hits = {};
    for (const rule of RULES) {
      let n = 0;
      for (const re of rule.patterns) n += countMatches(re, text);
      if (n > 0) hits[rule.id] = Math.min(n, 50);
    }
    return {
      hits,
      jobContext: countMatches(JOB_CONTEXT, text, 5) >= 2,
      educational: distinctMatches(EDUCATIONAL, text) >= 2,
      textLength: text.length,
    };
  }

  const RULE_META = Object.fromEntries(RULES.map((r) => [r.id, {
    label: r.label, category: r.category, weight: r.weight, needsJob: !!r.needsJob,
  }]));

  root.ScamSentryText = Object.freeze({ analyzeText, RULE_META, RULE_IDS: Object.freeze(RULES.map((r) => r.id)) });
})(globalThis);
