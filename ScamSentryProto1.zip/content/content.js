// Content script: reads the page locally, sends only rule counts to the worker.
(() => {
  'use strict';
  if (window.top !== window || globalThis.__scamSentryLoaded) return;
  globalThis.__scamSentryLoaded = true;

  const { analyzeText } = globalThis.ScamSentryText;
  const Banner = globalThis.ScamSentryBanner;
  const CHAT_HOSTS = new Set(['t.me', 'telegram.me', 'wa.me', 'chat.whatsapp.com', 'api.whatsapp.com']);
  const DANGEROUS_FILE_RE = /\.(apk|xapk|apks|exe|msi|scr|bat|cmd|ps1|vbs|jar|hta|lnk|dmg|pkg|iso)$/i;

  let lastUrl = location.href;
  let lastTextLength = 0;
  let scanning = null;
  let autoRescans = 0;

  function collectSignals() {
    const parts = [document.title || ''];
    const meta = document.querySelector('meta[name="description"]');
    if (meta) parts.push(meta.getAttribute('content') || '');
    parts.push(document.body ? document.body.innerText : '');
    const signals = analyzeText(parts.join('\n'));

    let offplatformLinks = 0;
    let execLinks = 0;
    const linkHosts = new Set();
    const here = location.hostname.toLowerCase();
    const anchors = document.querySelectorAll('a[href], iframe[src], area[href]');
    for (let i = 0; i < anchors.length && i < 3000; i++) {
      const el = anchors[i];
      let u;
      try { u = new URL(el.href || el.src, location.href); } catch { continue; }
      if (u.protocol !== 'http:' && u.protocol !== 'https:') continue;
      const h = u.hostname.toLowerCase();
      if (CHAT_HOSTS.has(h)) offplatformLinks++;
      const dl = el.getAttribute('download');
      if (DANGEROUS_FILE_RE.test(u.pathname) || (dl && DANGEROUS_FILE_RE.test(dl))) execLinks++;
      if (h !== here && linkHosts.size < 300) linkHosts.add(h);
    }
    // <meta http-equiv="refresh" content="0;url=https://elsewhere"> bouncing you to another site.
    let metaRefreshExternal = false;
    const refresh = document.querySelector('meta[http-equiv="refresh" i]');
    if (refresh) {
      const m = /url\s*=\s*['"]?([^'";]+)/i.exec(refresh.getAttribute('content') || '');
      const delay = parseFloat(refresh.getAttribute('content') || '');
      if (m && !(delay > 10)) {
        try {
          const target = new URL(m[1].trim(), location.href);
          if (target.hostname && target.hostname.toLowerCase() !== here) {
            metaRefreshExternal = true;
            if (linkHosts.size < 300) linkHosts.add(target.hostname.toLowerCase());
          }
        } catch { /* ignore */ }
      }
    }
    return {
      hits: signals.hits,
      jobContext: signals.jobContext,
      educational: signals.educational,
      textLength: signals.textLength,
      offplatformLinks,
      execLinks,
      metaRefreshExternal,
      linkHosts: [...linkHosts],
      hasPassword: !!document.querySelector('input[type="password"]'),
      hasPayment: !!document.querySelector('input[autocomplete^="cc-"], input[name*="card" i], input[name*="cvv" i], input[name*="upi" i], input[placeholder*="UPI" i]'),
    };
  }

  async function scan() {
    if (scanning) return scanning;
    scanning = (async () => {
      const signals = collectSignals();
      lastTextLength = signals.textLength;
      try {
        const res = await chrome.runtime.sendMessage({ v: 1, op: 'scan', signals, pageUrl: location.href });
        if (res?.ok) Banner.update(res.verdict);
        return res;
      } catch (e) {
        return { ok: false, error: 'worker-unavailable' }; // e.g. extension reloaded; page needs refresh
      } finally {
        scanning = null;
      }
    })();
    return scanning;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || !msg || msg.v !== 1) return false;
    if (msg.op === 'ping') { sendResponse({ ok: true }); return false; }
    if (msg.op === 'rescan') { Banner.resetDismiss(); scan().then(sendResponse); return true; }
    if (msg.op === 'verdict-update' && msg.verdict?.url === location.href) Banner.update(msg.verdict);
    return false;
  });

  // Single-page apps (LinkedIn, job boards) change URL and content without reloading.
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      autoRescans = 0;
      Banner.remove();
      setTimeout(scan, 1200);
    }
  }, 1500);

  // Re-scan once content that loads late (job descriptions, chat widgets) has settled.
  let debounce = null;
  const observer = new MutationObserver(() => {
    if (autoRescans >= 6) return;
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      const len = document.body ? document.body.innerText.length : 0;
      if (Math.abs(len - lastTextLength) > Math.max(400, lastTextLength * 0.25)) {
        autoRescans++;
        scan();
      }
    }, 1500);
  });
  if (document.body) observer.observe(document.body, { childList: true, subtree: true });

  // Tell the worker the user is actually using this page, so a navigation that follows
  // isn't mistaken for an automatic (no-click) redirect. Sent once per document.
  let reportedInteraction = false;
  const onInteract = (e) => {
    if (!e.isTrusted || reportedInteraction) return;
    reportedInteraction = true;
    chrome.runtime.sendMessage({ v: 1, op: 'interacted' }).catch(() => {});
  };
  for (const type of ['pointerdown', 'keydown']) window.addEventListener(type, onInteract, { capture: true, passive: true });

  scan();
})();
