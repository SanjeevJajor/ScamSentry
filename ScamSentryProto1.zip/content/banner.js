// In-page warning banner. Closed shadow DOM so page CSS/scripts can't restyle or read it.
// All page-derived strings are inserted with textContent (never innerHTML).
((root) => {
  'use strict';

  const HOST_TAG = 'scamsentry-banner';
  let host = null;
  let shadow = null;
  let dismissedFor = null;

  const CSS = `
    :host { all: initial; }
    .bar { position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
      font: 14px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      background: #fff5f5; color: #3b0d0d; border-bottom: 3px solid var(--accent);
      box-shadow: 0 4px 16px rgba(0,0,0,.18); }
    .row { display: flex; align-items: center; gap: 12px; padding: 10px 16px; flex-wrap: wrap; }
    .icon { flex: none; width: 28px; height: 28px; border-radius: 50%; background: var(--accent);
      color: #fff; display: grid; place-items: center; font-weight: 700; font-size: 16px; }
    .msg { flex: 1 1 320px; min-width: 0; }
    .title { font-weight: 700; }
    .why { color: #5c1a1a; }
    .actions { display: flex; gap: 8px; flex-wrap: wrap; }
    button { font: inherit; font-size: 13px; padding: 6px 12px; border-radius: 6px; cursor: pointer;
      border: 1px solid #8a2a2a; background: #fff; color: #5c1010; }
    button.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
    button:focus-visible { outline: 3px solid #1d4ed8; outline-offset: 2px; }
    ul { margin: 0; padding: 4px 16px 12px 56px; display: none; }
    ul.open { display: block; }
    li { margin: 2px 0; }
    .pts { font-weight: 700; font-variant-numeric: tabular-nums; margin-right: 6px; }
    .caution { background: #fffaf0; color: #3d2603; }
    .caution .why { color: #5a3a07; }
    .foot { font-size: 12px; opacity: .8; padding: 0 16px 10px 56px; display: none; }
    .foot.open { display: block; }
  `;

  function el(tag, attrs = {}, text) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function remove() {
    if (host) host.remove();
    host = null;
    shadow = null;
  }

  /** @param {{score:number, level:string, reasons:{label:string, points:number}[], url:string}} verdict */
  function show(verdict) {
    if (dismissedFor === verdict.url) return;
    remove();
    const accent = verdict.level === 'high' ? '#c62828' : '#b45309';
    host = document.createElement(HOST_TAG);
    shadow = host.attachShadow({ mode: 'closed' });
    const style = el('style'); style.textContent = CSS;
    const bar = el('div', { class: `bar ${verdict.level}`, role: 'alert', 'aria-label': 'ScamSentry warning' });
    bar.style.setProperty('--accent', accent);

    const positives = verdict.reasons.filter((r) => r.points > 0);
    const top = positives.slice(0, 2).map((r) => r.label).join(' · ');
    const row = el('div', { class: 'row' });
    row.append(el('div', { class: 'icon', 'aria-hidden': 'true' }, '!'));
    const msg = el('div', { class: 'msg' });
    const word = verdict.level === 'high' ? 'High scam risk' : 'Be careful';
    msg.append(el('div', { class: 'title' }, `ScamSentry: ${word} (${verdict.score}/100)`));
    if (top) msg.append(el('div', { class: 'why' }, top));
    row.append(msg);

    const list = el('ul', { id: 'ss-reasons' });
    for (const r of positives) {
      const li = el('li');
      li.append(el('span', { class: 'pts' }, `+${r.points}`), document.createTextNode(r.label));
      list.append(li);
    }
    const foot = el('div', { class: 'foot' }, 'This is a risk signal, not proof. Never pay fees or share OTPs to get a job, and never install apps (.apk/.exe) from links like this. Report fraud at cybercrime.gov.in or call 1930.');

    const actions = el('div', { class: 'actions' });
    const details = el('button', { type: 'button', 'aria-expanded': 'false', 'aria-controls': 'ss-reasons' }, 'Details');
    const back = el('button', { type: 'button', class: 'primary' }, 'Go back');
    const dismiss = el('button', { type: 'button' }, 'Dismiss');
    // Ignore synthetic clicks dispatched by page scripts.
    details.addEventListener('click', (e) => {
      if (!e.isTrusted) return;
      const open = list.classList.toggle('open');
      foot.classList.toggle('open', open);
      details.setAttribute('aria-expanded', String(open));
    });
    back.addEventListener('click', (e) => {
      if (!e.isTrusted) return;
      if (history.length > 1) history.back(); else location.replace('about:blank');
    });
    dismiss.addEventListener('click', (e) => {
      if (!e.isTrusted) return;
      dismissedFor = verdict.url;
      remove();
    });
    actions.append(details, back, dismiss);
    row.append(actions);
    bar.append(row, list, foot);
    shadow.append(style, bar);
    (document.body || document.documentElement).append(host);
  }

  root.ScamSentryBanner = Object.freeze({
    update(verdict) { if (verdict && verdict.showBanner) show(verdict); else remove(); },
    remove,
    resetDismiss() { dismissedFor = null; },
  });
})(globalThis);
