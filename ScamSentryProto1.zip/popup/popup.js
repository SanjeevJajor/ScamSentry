// Popup: shows the verdict for the active tab. Talks only to our service worker / content script.
const $ = (id) => document.getElementById(id);
const LEVEL = {
  low: { word: 'Looks safe', summary: 'No strong warning signs on this page.', css: 'var(--low)' },
  caution: { word: 'Be careful', summary: 'Some warning signs. Double-check before you share details or pay.', css: 'var(--caution)' },
  high: { word: 'High scam risk', summary: 'Several scam signals. Don\'t pay, download files, or share OTPs or IDs here.', css: 'var(--high)' },
};
const CATEGORY = { job: 'Job offer', payment: 'Payment / ID', pressure: 'Pressure tactic', link: 'Web address', domain: 'Domain', report: 'Threat report', redirect: 'Redirect', malware: 'Malware' };
const HOP_KIND = { redirect: 'redirected you onward', auto: 'sent you on automatically (no click)', opener: 'opened this tab' };
const CIRC = 2 * Math.PI * 34;

let tabId = null;
let current = null;

function showState(name) {
  for (const s of ['loading', 'unsupported', 'verdict']) $(`state-${s}`).hidden = s !== name;
  $('actions').hidden = name !== 'verdict';
}

const send = (msg) => chrome.runtime.sendMessage({ v: 1, ...msg });

function ageText(v) {
  if (v.trusted) return '';
  if (v.ageDays !== null && v.ageDays !== undefined) {
    if (v.ageDays < 365) return `· registered ${v.ageDays} day${v.ageDays === 1 ? '' : 's'} ago`;
    return `· registered ${Math.floor(v.ageDays / 365)}+ years ago`;
  }
  if (v.ageStatus === 'pending') return '· checking age…';
  if (v.topSite) return '· well-known site';
  return '';
}

function render(v) {
  current = v;
  const lvl = LEVEL[v.level] || LEVEL.low;
  document.body.style.setProperty('--level', lvl.css);
  $('score-num').textContent = String(v.score);
  const fg = $('ring-fg');
  fg.style.strokeDasharray = String(CIRC);
  fg.style.strokeDashoffset = String(CIRC * (1 - Math.max(v.score, 2) / 100));
  $('level-word').textContent = v.trusted ? 'Trusted by you' : lvl.word;
  $('summary').textContent = v.trusted ? 'You marked this site as trusted, so ScamSentry skips it.' : lvl.summary;
  $('score-num').setAttribute('aria-label', `Risk score ${v.score} out of 100`);
  document.querySelector('.ring').setAttribute('aria-label', `Risk score ${v.score} out of 100, ${lvl.word}`);
  $('site-domain').textContent = v.domain || v.host || '';
  $('site-age').textContent = ageText(v);

  const list = $('reasons');
  list.replaceChildren();
  for (const r of v.reasons) {
    const li = document.createElement('li');
    const chip = document.createElement('span');
    chip.className = r.points < 0 ? 'chip neg' : 'chip';
    chip.textContent = r.points < 0 ? `${r.points}` : `+${r.points}`;
    chip.setAttribute('aria-label', r.points < 0 ? `minus ${-r.points} points` : `plus ${r.points} points`);
    const body = document.createElement('div');
    const label = document.createElement('div');
    label.textContent = r.label;
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = CATEGORY[r.category] || r.category;
    body.append(label, tag);
    li.append(chip, body);
    list.append(li);
  }
  $('no-reasons').hidden = v.reasons.length > 0 || v.trusted;

  const hops = v.chain || [];
  $('route').hidden = hops.length === 0;
  const route = $('route-list');
  route.replaceChildren();
  for (const h of hops) {
    const li = document.createElement('li');
    if (h.bad) li.className = 'bad';
    li.textContent = h.host;
    const how = document.createElement('span');
    how.className = 'how';
    how.textContent = HOP_KIND[h.kind] || 'redirected you';
    if (h.bad) {
      const tag = document.createElement('span');
      tag.className = 'bad-tag';
      tag.textContent = ' · reported for phishing/malware';
      how.append(tag);
    }
    li.append(how);
    route.append(li);
  }
  if (hops.length) {
    const here = document.createElement('li');
    here.className = 'here';
    here.textContent = v.host;
    const how = document.createElement('span');
    how.className = 'how';
    how.textContent = 'this page';
    here.append(how);
    route.append(here);
  }

  const notes = $('notes');
  notes.replaceChildren();
  for (const n of v.notes || []) {
    const li = document.createElement('li');
    li.textContent = n;
    notes.append(li);
  }
  $('trust').textContent = v.trusted ? 'Stop trusting' : 'Trust this site';
  $('trust').disabled = !v.domain;
  showState('verdict');
}

async function load() {
  // popup.html?tab=<id> lets the popup be opened as a page for a specific tab (testing/demo screenshots).
  const forced = Number.parseInt(new URLSearchParams(location.search).get('tab') || '', 10);
  if (Number.isInteger(forced)) tabId = forced;
  else {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return showState('unsupported');
    tabId = tab.id;
  }
  const res = await send({ op: 'get-verdict', tabId });
  if (res?.ok) return render(res.verdict);
  // Not scanned yet: is our content script on this page?
  try {
    await chrome.tabs.sendMessage(tabId, { v: 1, op: 'ping' }, { frameId: 0 });
  } catch {
    return showState('unsupported');
  }
  const r2 = await send({ op: 'rescan', tabId });
  if (r2?.ok) render(r2.verdict); else showState('unsupported');
}

$('rescan').addEventListener('click', async () => {
  showState('loading');
  const r = await send({ op: 'rescan', tabId });
  if (r?.ok) render(r.verdict); else showState('unsupported');
});

$('trust').addEventListener('click', async () => {
  if (!current) return;
  const op = current.trusted ? 'untrust-site' : 'trust-site';
  $('trust').disabled = true;
  const r = await send({ op, tabId, domain: current.domain });
  if (r?.ok && r.verdict) render(r.verdict);
  else await load();
});

$('open-options').addEventListener('click', () => chrome.runtime.openOptionsPage());

// The worker refines the verdict once the domain-age lookup finishes.
chrome.storage.session.onChanged.addListener((changes) => {
  const c = tabId !== null && changes[`tab:${tabId}`];
  if (c?.newValue?.verdict) render(c.newValue.verdict);
});

load().catch(() => showState('unsupported'));
