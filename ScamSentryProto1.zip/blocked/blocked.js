// Blocked-page logic. The blocked URL arrives in the fragment (set by our declarativeNetRequest rule).
const $ = (id) => document.getElementById(id);
const raw = decodeURIComponent(location.hash.slice(1) || '');
let blocked = null;
try { blocked = new URL(raw); } catch { /* unknown */ }
if (blocked && /^https?:$/.test(blocked.protocol)) {
  $('url').textContent = blocked.href; // textContent only — never interpreted as HTML
  $('addr').hidden = false;
}

$('back').addEventListener('click', () => {
  if (history.length > 2) history.go(-2); // skip the redirecting hop that would bounce us back
  else if (history.length > 1) history.back();
  else location.replace('about:blank');
});

// "Continue anyway" only in a real top-level tab: if a website frames this page, it can't
// trick the user into unblocking anything.
if (window.top === window && blocked && /^https?:$/.test(blocked.protocol)) {
  $('continue').hidden = false;
  $('continue').addEventListener('click', async (e) => {
    if (!e.isTrusted) return;
    const r = await chrome.runtime.sendMessage({ v: 1, op: 'allow-host', host: blocked.hostname.toLowerCase() });
    if (r?.ok) location.replace(blocked.href);
  });
}
