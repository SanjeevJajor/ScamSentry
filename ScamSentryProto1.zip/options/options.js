const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage({ v: 1, ...msg });

function toast(text) {
  $('toast').textContent = text;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { $('toast').textContent = ''; }, 4000);
}

function feedText(feed, enabled) {
  if (!enabled) return 'Off.';
  if (feed.error && !feed.count) return `Couldn't download the feed yet (${feed.error.message}). Built-in list in use.`;
  if (!feed.count) return 'Not downloaded yet — built-in list in use.';
  return `${feed.count.toLocaleString()} reported sites · updated ${new Date(feed.fetchedAt).toLocaleString()}`;
}

const MALWARE_ERRORS = {
  'urlhaus-key-rejected': 'URLhaus rejected this key — check it and try again.',
  'urlhaus-network-error': 'Could not reach URLhaus. Check your connection.',
  'no-urlhaus-key': 'No key saved.',
  'bad-key-format': 'That doesn\'t look like a URLhaus key (letters and numbers only).',
};
function malwareText(m) {
  if (!m.hasKey) return 'No key saved — malware list off.';
  if (m.error && !m.count) return MALWARE_ERRORS[m.error.message] || `Download failed (${m.error.message}).`;
  if (!m.count) return 'Key saved. Downloading list…';
  const blocking = m.blockingRules > 0 ? ` · blocking active (${m.blockingRules} rules)` : ' · blocking off';
  return `${m.count.toLocaleString()} malware sites · updated ${new Date(m.fetchedAt).toLocaleString()}${blocking}`;
}

function renderTrusted(list) {
  const ul = $('trusted');
  ul.replaceChildren();
  for (const d of list) {
    const li = document.createElement('li');
    const span = document.createElement('span');
    span.textContent = d;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn';
    btn.textContent = 'Remove';
    btn.setAttribute('aria-label', `Stop trusting ${d}`);
    btn.addEventListener('click', async () => {
      const r = await send({ op: 'untrust-site', domain: d });
      if (r?.ok) { renderTrusted(r.trusted); toast(`${d} removed.`); }
    });
    li.append(span, btn);
    ul.append(li);
  }
  $('trusted-empty').hidden = list.length > 0;
}

async function load() {
  const r = await send({ op: 'get-settings' });
  if (!r?.ok) return toast('Could not load settings.');
  $('rdapEnabled').checked = r.settings.rdapEnabled;
  $('feedEnabled').checked = r.settings.feedEnabled;
  $('redirectTracking').checked = r.settings.redirectTracking;
  $('malwareBlock').checked = r.settings.malwareBlock;
  $('malwareBlock').disabled = !r.malware.hasKey;
  $('remove-key').hidden = !r.malware.hasKey;
  $('urlhaus-key').placeholder = r.malware.hasKey ? 'Key saved on this device (paste a new one to replace)' : 'Paste your URLhaus Auth-Key';
  $('malware-status').textContent = malwareText(r.malware);
  for (const el of document.querySelectorAll('input[name="bannerLevel"]')) el.checked = el.value === r.settings.bannerLevel;
  $('feed-status').textContent = feedText(r.feed, r.settings.feedEnabled);
  renderTrusted(r.trusted);
}

async function save(patch) {
  const r = await send({ op: 'set-settings', settings: patch });
  toast(r?.ok ? 'Saved.' : 'Could not save.');
  await load();
}

$('rdapEnabled').addEventListener('change', (e) => save({ rdapEnabled: e.target.checked }));
$('feedEnabled').addEventListener('change', (e) => save({ feedEnabled: e.target.checked }));
$('redirectTracking').addEventListener('change', (e) => save({ redirectTracking: e.target.checked }));
$('malwareBlock').addEventListener('change', (e) => save({ malwareBlock: e.target.checked }));
$('key-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = $('urlhaus-key');
  const key = input.value.trim();
  if (!key) return;
  $('save-key').disabled = true;
  $('malware-status').textContent = 'Saving key and downloading the malware list…';
  const r = await send({ op: 'set-urlhaus-key', key });
  input.value = ''; // don't keep the key in the page
  $('save-key').disabled = false;
  toast(r?.ok ? `Malware list ready: ${r.count.toLocaleString()} sites.` : (MALWARE_ERRORS[r?.error] || `Failed (${r?.error || 'unknown'}).`));
  load();
});
$('remove-key').addEventListener('click', async () => {
  await send({ op: 'remove-urlhaus-key' });
  toast('Key and malware list removed.');
  load();
});
for (const el of document.querySelectorAll('input[name="bannerLevel"]')) {
  el.addEventListener('change', (e) => save({ bannerLevel: e.target.value }));
}
$('refresh-feed').addEventListener('click', async () => {
  $('refresh-feed').disabled = true;
  toast('Updating feed…');
  const r = await send({ op: 'refresh-feed' });
  $('refresh-feed').disabled = false;
  toast(r?.ok ? `Feed updated: ${r.count.toLocaleString()} sites.` : `Update failed (${r?.error || 'unknown error'}).`);
  load();
});
$('clear-cache').addEventListener('click', async () => {
  const r = await send({ op: 'clear-cache' });
  toast(r?.ok ? `Cleared ${r.removed} cached domain${r.removed === 1 ? '' : 's'}.` : 'Could not clear cache.');
});

if (new URLSearchParams(location.search).has('welcome')) $('welcome').hidden = false;
load();
