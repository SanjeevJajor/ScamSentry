// ScamSentry service worker (MV3, ES module).
// Listeners are registered synchronously at top level; all state lives in chrome.storage.
import './content/text-rules.js'; // side-effect: defines globalThis.ScamSentryText (rule metadata)
import { analyzeUrl } from './lib/url-analyzer.js';
import { computeVerdict, LEVELS } from './lib/scoring.js';
import { getDomainAge } from './lib/rdap.js';
import { isKnownBad, refreshFeed } from './lib/feed.js';
import {
  isKnownMalware, countMalwareHosts, refreshMalware, applyBlocking, allowHostForSession, KEY_RE,
} from './lib/malware.js';
import * as Nav from './lib/redirects.js';
import { splitHost } from './lib/url-analyzer.js';

const { RULE_META, RULE_IDS } = globalThis.ScamSentryText;
const local = chrome.storage.local;
const session = chrome.storage.session;
const EXT_ORIGIN = chrome.runtime.getURL('');
const FEED_ALARM = 'feed-refresh';
const DEFAULT_SETTINGS = Object.freeze({ rdapEnabled: true, feedEnabled: true, redirectTracking: true, malwareBlock: true, bannerLevel: 'high' });
const BLOCKED_PAGE = chrome.runtime.getURL('blocked.html');
const BANNER_LEVELS = ['high', 'caution', 'never'];

// ---------- settings ----------
async function getSettings() {
  const { settings } = await local.get('settings');
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}
async function getTrusted() {
  const { trusted } = await local.get('trusted');
  return Array.isArray(trusted) ? trusted : [];
}

// ---------- validation ----------
function sanitizeSignals(s) {
  if (!s || typeof s !== 'object') return null;
  const hits = {};
  if (s.hits && typeof s.hits === 'object') {
    for (const id of RULE_IDS) {
      const n = Number(s.hits[id]);
      if (Number.isFinite(n) && n > 0) hits[id] = Math.min(50, Math.floor(n));
    }
  }
  const clampInt = (v, max) => (Number.isFinite(Number(v)) ? Math.max(0, Math.min(max, Math.floor(Number(v)))) : 0);
  return {
    hits,
    jobContext: s.jobContext === true,
    educational: s.educational === true,
    hasPassword: s.hasPassword === true,
    hasPayment: s.hasPayment === true,
    offplatformLinks: clampInt(s.offplatformLinks, 50),
    execLinks: clampInt(s.execLinks, 50),
    metaRefreshExternal: s.metaRefreshExternal === true,
    // Hostnames this page links to / embeds. Checked locally against the malware list; never sent anywhere.
    linkHosts: Array.isArray(s.linkHosts)
      ? s.linkHosts.filter((h) => typeof h === 'string' && /^[a-z0-9.-]{1,253}$/.test(h)).slice(0, 300)
      : [],
  };
}
const fromExtensionPage = (sender) => sender.id === chrome.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(EXT_ORIGIN);
const fromTopFrameContentScript = (sender) => sender.id === chrome.runtime.id && sender.tab && sender.frameId === 0 && /^https?:/.test(sender.url || '');

// ---------- badge ----------
async function paintBadge(tabId, verdict) {
  try {
    if (!verdict) {
      await chrome.action.setBadgeText({ tabId, text: '' });
      await chrome.action.setTitle({ tabId, title: 'ScamSentry' });
      return;
    }
    const color = verdict.trusted ? '#1a7f37' : LEVELS[verdict.level].color;
    const text = verdict.trusted ? '✓' : String(verdict.score);
    const word = verdict.trusted ? 'Trusted site' : `${LEVELS[verdict.level].word} (${verdict.score}/100)`;
    await chrome.action.setBadgeBackgroundColor({ tabId, color });
    await chrome.action.setBadgeTextColor?.({ tabId, color: '#ffffff' });
    await chrome.action.setBadgeText({ tabId, text });
    await chrome.action.setTitle({ tabId, title: `ScamSentry: ${word}` });
  } catch {
    // Tab may have closed between scan and paint — nothing to do.
  }
}

function shouldShowBanner(verdict, settings) {
  if (verdict.trusted || settings.bannerLevel === 'never') return false;
  if (settings.bannerLevel === 'caution') return verdict.level !== 'low';
  return verdict.level === 'high';
}

// ---------- scan pipeline ----------
async function scanTab(tabId, url, signals) {
  const urlInfo = analyzeUrl(url);
  if (!urlInfo) return { ok: false, error: 'unsupported-url' };
  const [settings, trustedList] = await Promise.all([getSettings(), getTrusted()]);
  const trusted = trustedList.includes(urlInfo.registrable) || trustedList.includes(urlInfo.host);
  const feedHit = !trusted && await isKnownBad(urlInfo, local);
  const malwareHit = !trusted && await isKnownMalware(urlInfo, local);
  const malwareLinks = trusted || !signals ? 0 : await countMalwareHosts(signals.linkHosts || [], local);
  const chain = settings.redirectTracking ? await chainWithReputation(tabId, urlInfo.url) : [];

  // Phase 1: answer quickly using a cached domain age (if any).
  let age = { status: 'skipped', created: null };
  let needsLookup = false;
  if (urlInfo.ageEligible && !trusted) {
    if (!settings.rdapEnabled) age = { status: 'disabled', created: null };
    else {
      const key = `age:${urlInfo.registrable}`;
      const cached = (await local.get(key))[key];
      if (cached && cached.status !== 'error') age = cached;
      else { age = { status: 'pending', created: null }; needsLookup = true; }
    }
  }

  const build = (a) => {
    const v = computeVerdict({ urlInfo, signals, ruleMeta: RULE_META, age: a, feedHit, trusted, chain, malwareHit, malwareLinks });
    return { ...v, url: urlInfo.url, showBanner: shouldShowBanner(v, settings) };
  };

  const verdict = build(age);
  await session.set({ [`tab:${tabId}`]: { verdict, signals } });
  await paintBadge(tabId, verdict);

  if (needsLookup) {
    // Phase 2: look up domain age, then push the refined verdict to the page.
    getDomainAge(urlInfo.registrable, { storage: local, session }).then(async (result) => {
      const current = (await session.get(`tab:${tabId}`))[`tab:${tabId}`];
      if (!current || current.verdict.url !== urlInfo.url) return; // tab navigated away
      const refined = build(result);
      await session.set({ [`tab:${tabId}`]: { verdict: refined, signals } });
      await paintBadge(tabId, refined);
      chrome.tabs.sendMessage(tabId, { v: 1, op: 'verdict-update', verdict: refined }, { frameId: 0 }).catch(() => {});
    }).catch(() => {});
  }
  return { ok: true, verdict };
}

async function rescanFromStored(tabId) {
  // Ask the page to re-read its text; fall back to stored signals if the content script is gone.
  try {
    const res = await chrome.tabs.sendMessage(tabId, { v: 1, op: 'rescan' }, { frameId: 0 });
    if (res?.ok) return res;
  } catch { /* fall through */ }
  const stored = (await session.get(`tab:${tabId}`))[`tab:${tabId}`];
  if (!stored) return { ok: false, error: 'not-scanned' };
  return scanTab(tabId, stored.verdict.url, stored.signals);
}

// ---------- message router ----------
async function handle(msg, sender) {
  if (!msg || msg.v !== 1 || typeof msg.op !== 'string') return { ok: false, error: 'bad-message' };

  if (msg.op === 'scan') {
    if (!fromTopFrameContentScript(sender)) return { ok: false, error: 'forbidden' };
    // sender.url doesn't follow history.pushState (SPAs). Accept the page's own URL only if it is
    // same-origin with what the browser reports, so a page can't claim to be another site.
    let url = sender.url;
    if (typeof msg.pageUrl === 'string' && msg.pageUrl.length < 4096) {
      try { if (new URL(msg.pageUrl).origin === new URL(sender.url).origin) url = msg.pageUrl; } catch { /* keep sender.url */ }
    }
    return scanTab(sender.tab.id, url, sanitizeSignals(msg.signals));
  }

  if (msg.op === 'interacted') {
    if (!fromTopFrameContentScript(sender)) return { ok: false, error: 'forbidden' };
    const origin = new URL(sender.url).origin;
    await updateNav(sender.tab.id, (nav) => Nav.onInteract(nav, origin));
    return { ok: true };
  }

  // Everything below is privileged: only our own extension pages (popup/options).
  if (!fromExtensionPage(sender)) return { ok: false, error: 'forbidden' };
  const tabId = Number.isInteger(msg.tabId) ? msg.tabId : null;

  switch (msg.op) {
    case 'get-verdict': {
      if (tabId === null) return { ok: false, error: 'bad-tab' };
      const stored = (await session.get(`tab:${tabId}`))[`tab:${tabId}`];
      return stored ? { ok: true, verdict: stored.verdict } : { ok: false, error: 'not-scanned' };
    }
    case 'rescan':
      if (tabId === null) return { ok: false, error: 'bad-tab' };
      return rescanFromStored(tabId);
    case 'trust-site':
    case 'untrust-site': {
      let domain = typeof msg.domain === 'string' ? msg.domain.toLowerCase() : null;
      if (!domain && tabId !== null) {
        const stored = (await session.get(`tab:${tabId}`))[`tab:${tabId}`];
        domain = stored?.verdict?.domain || null;
      }
      if (!domain || !/^[a-z0-9.-]{1,253}$/.test(domain)) return { ok: false, error: 'bad-domain' };
      const list = await getTrusted();
      const next = msg.op === 'trust-site'
        ? [...new Set([...list, domain])].slice(-500)
        : list.filter((d) => d !== domain);
      await local.set({ trusted: next });
      if (tabId !== null) return rescanFromStored(tabId);
      return { ok: true, trusted: next };
    }
    case 'get-settings': {
      const [settings, trusted, store] = await Promise.all([
        getSettings(), getTrusted(), local.get(['feed', 'feedError', 'malware', 'malwareError', 'urlhausKey']),
      ]);
      const rules = (await chrome.declarativeNetRequest.getDynamicRules()).length;
      return {
        ok: true, settings, trusted,
        feed: { count: store.feed?.count || 0, fetchedAt: store.feed?.fetchedAt || null, error: store.feedError || null },
        // The key itself is never returned to any page — only whether one is saved.
        malware: {
          hasKey: typeof store.urlhausKey === 'string' && store.urlhausKey.length > 0,
          count: store.malware?.count || 0, fetchedAt: store.malware?.fetchedAt || null,
          error: store.malwareError || null, blockingRules: rules,
        },
      };
    }
    case 'set-settings': {
      const cur = await getSettings();
      const p = msg.settings || {};
      const next = {
        rdapEnabled: typeof p.rdapEnabled === 'boolean' ? p.rdapEnabled : cur.rdapEnabled,
        feedEnabled: typeof p.feedEnabled === 'boolean' ? p.feedEnabled : cur.feedEnabled,
        redirectTracking: typeof p.redirectTracking === 'boolean' ? p.redirectTracking : cur.redirectTracking,
        malwareBlock: typeof p.malwareBlock === 'boolean' ? p.malwareBlock : cur.malwareBlock,
        bannerLevel: BANNER_LEVELS.includes(p.bannerLevel) ? p.bannerLevel : cur.bannerLevel,
      };
      await local.set({ settings: next });
      await scheduleFeed(next);
      await syncBlocking(next);
      return { ok: true, settings: next };
    }
    case 'refresh-feed':
      return doFeedRefresh();
    case 'set-urlhaus-key': {
      const key = typeof msg.key === 'string' ? msg.key.trim() : '';
      if (!KEY_RE.test(key)) return { ok: false, error: 'bad-key-format' };
      await local.set({ urlhausKey: key });
      const r = await doMalwareRefresh();
      if (!r.ok && r.error === 'urlhaus-key-rejected') await local.remove('urlhausKey');
      return r;
    }
    case 'remove-urlhaus-key':
      await local.remove(['urlhausKey', 'malware', 'malwareError']);
      await syncBlocking(await getSettings());
      return { ok: true };
    case 'allow-host': {
      // From the blocked page's "Continue anyway" (top-level only; see blocked.js).
      const host = typeof msg.host === 'string' ? msg.host.toLowerCase() : '';
      if (sender.frameId !== 0 && sender.frameId !== undefined) return { ok: false, error: 'forbidden' };
      await allowHostForSession(chrome.declarativeNetRequest, host);
      return { ok: true };
    }
    case 'clear-cache': {
      const all = await local.get(null);
      const keys = Object.keys(all).filter((k) => k.startsWith('age:'));
      if (keys.length) await local.remove(keys);
      return { ok: true, removed: keys.length };
    }
    default:
      return { ok: false, error: 'unknown-op' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender).then(sendResponse, (err) => sendResponse({ ok: false, error: String(err?.message || err) }));
  return true; // async response
});

// ---------- feed scheduling ----------
async function doFeedRefresh() {
  const settings = await getSettings();
  if (!settings.feedEnabled) return { ok: false, error: 'feed-disabled' };
  doMalwareRefresh(); // independent list; runs alongside, reports its own status
  try {
    const r = await refreshFeed(local);
    await local.remove('feedError');
    return { ok: true, ...r };
  } catch (e) {
    await local.set({ feedError: { message: String(e?.message || e), at: Date.now() } });
    return { ok: false, error: String(e?.message || e) };
  }
}

async function doMalwareRefresh() {
  const { urlhausKey } = await local.get('urlhausKey');
  if (!urlhausKey) return { ok: false, error: 'no-urlhaus-key' };
  try {
    const r = await refreshMalware(local);
    await local.remove('malwareError');
    await syncBlocking(await getSettings());
    return { ok: true, ...r };
  } catch (e) {
    // Error codes are fixed strings from malware.js — they never contain the key.
    const message = String(e?.message || e).slice(0, 80);
    await local.set({ malwareError: { message, at: Date.now() } });
    return { ok: false, error: message };
  }
}

async function syncBlocking(settings) {
  try {
    return await applyBlocking(chrome.declarativeNetRequest, local, {
      enabled: settings.malwareBlock && settings.feedEnabled, blockedPageUrl: BLOCKED_PAGE,
    });
  } catch {
    return 0;
  }
}

async function scheduleFeed(settings) {
  if (!settings.feedEnabled) { await chrome.alarms.clear(FEED_ALARM); return; }
  const existing = await chrome.alarms.get(FEED_ALARM);
  if (!existing) await chrome.alarms.create(FEED_ALARM, { periodInMinutes: 360, delayInMinutes: 360 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === FEED_ALARM) doFeedRefresh();
});

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const settings = await getSettings();
  await scheduleFeed(settings);
  await syncBlocking(settings); // updates keep the downloaded list; rebuild rules for the new version
  if (reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html?welcome=1') });
    doFeedRefresh();
  }
});

chrome.runtime.onStartup.addListener(async () => {
  const settings = await getSettings();
  await scheduleFeed(settings);
  await syncBlocking(settings); // dynamic rules persist, but re-sync in case the list changed
});

// ---------- tab lifecycle ----------
chrome.tabs.onRemoved.addListener((tabId) => {
  navCache.delete(tabId);
  session.remove([`tab:${tabId}`, `nav:${tabId}`]);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  // A new document is loading: the old verdict no longer applies. The content script rescans.
  if (changeInfo.status === 'loading') {
    session.remove(`tab:${tabId}`);
    paintBadge(tabId, null);
  }
});

// ---------- redirect-chain tracking ("how you got here") ----------
// Observe-only webRequest: we never block or modify requests. Only main-frame navigations are
// recorded, as hostnames, per tab, in memory-backed session storage that is cleared when the tab closes.
const navCache = new Map();   // tabId → nav state (fast path; session storage survives worker restarts)
const navQueue = new Map();   // tabId → promise, serialises updates for one tab

function updateNav(tabId, fn) {
  const prev = navQueue.get(tabId) || Promise.resolve();
  const next = prev.then(async () => {
    let nav = navCache.get(tabId);
    if (!nav) nav = (await session.get(`nav:${tabId}`))[`nav:${tabId}`] || Nav.emptyNav();
    const updated = fn(nav);
    navCache.set(tabId, updated);
    await session.set({ [`nav:${tabId}`]: updated });
    return updated;
  }).catch(() => Nav.emptyNav());
  navQueue.set(tabId, next);
  return next;
}

async function readNav(tabId) {
  await (navQueue.get(tabId) || Promise.resolve());
  return navCache.get(tabId) || (await session.get(`nav:${tabId}`))[`nav:${tabId}`] || null;
}

async function chainWithReputation(tabId, url) {
  const hops = Nav.chainFor(await readNav(tabId), url);
  return Promise.all(hops.map(async (h) => {
    const { registrable } = splitHost(h.host);
    const info = { host: h.host, registrable, url: `https://${h.host}/` };
    const bad = (await isKnownBad(info, local)) || (await isKnownMalware(info, local));
    return { ...h, bad };
  }));
}

let trackingOn = true;
getSettings().then((s) => { trackingOn = s.redirectTracking; });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) trackingOn = changes.settings.newValue?.redirectTracking !== false;
});

const MAIN_FRAME = { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] };
chrome.webRequest.onBeforeRequest.addListener((d) => {
  if (d.tabId < 0 || !trackingOn) return;
  updateNav(d.tabId, (nav) => Nav.onRequest(nav, { url: d.url, initiator: d.initiator, timeStamp: d.timeStamp, requestId: d.requestId }));
}, MAIN_FRAME);
chrome.webRequest.onBeforeRedirect.addListener((d) => {
  if (d.tabId < 0 || !trackingOn) return;
  updateNav(d.tabId, (nav) => Nav.onRedirect(nav, { url: d.url }));
}, MAIN_FRAME);
chrome.webRequest.onResponseStarted.addListener((d) => {
  if (d.tabId < 0 || !trackingOn) return;
  updateNav(d.tabId, (nav) => Nav.onCommit(nav, { url: d.url, timeStamp: d.timeStamp }));
}, MAIN_FRAME);
chrome.webRequest.onErrorOccurred.addListener((d) => {
  if (d.tabId < 0 || !trackingOn) return;
  updateNav(d.tabId, (nav) => Nav.onError(nav));
}, MAIN_FRAME);
